const express = require("express");
const mongoose = require("mongoose");
const app = express();
const BrandName = require("./model");

const PORT = process.env.PORT || 8000;

const url =
  "mongodb+srv://SamaraSimhaReddy:SamaraSimhaReddy@cluster0.uexeskd.mongodb.net/?retryWrites=true&w=majority";

app.use(express.json());

const db = mongoose
  .connect(url, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => console.log("Successfully connected to MongoDB"))
  .catch((error) => console.log(error));

app.listen(PORT, () => {
  console.log(`Server started on port ${PORT}`);
});

app
  .route("/brands")
  // GET METHOD
  .get(async (req, res) => {
    try {
      const allData = await BrandName.find();
      return res.json(allData);
    } catch (err) {
      console.log(err.message);
    }
  })


  .post(async (req, res) => {
    const { brandname } = req.body;
    try {
      const newData = new BrandName({ brandname });
      await newData.save();
      return res.json(await BrandName.find());
    } catch (err) {
      console.log(err.message);
    }
  })

  // PUT METHOD
  .put(async (req, res) => {
    const { title } = req.body;
    const { id } = req.query;
    try {
      const updatedBrand = await BrandName.findByIdAndUpdate(
        id,
        { title },
        { new: true }
      );
      return res.json(updatedBrand);
    } catch (err) {
      console.log(err.message);
    }
  })
  // DELETE METHOD
  .delete(async (req, res) => {
    const { id } = req.query;
    try {
      await BrandName.findByIdAndDelete(id);
      return res.json(await BrandName.find());
    } catch (err) {
      console.log(err.message);
    }
  });

app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).send("Something broke!");
});
